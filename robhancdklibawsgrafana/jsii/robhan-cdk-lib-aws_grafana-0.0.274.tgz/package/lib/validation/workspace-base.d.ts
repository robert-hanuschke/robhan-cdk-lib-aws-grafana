/**
 * Validates the clientToken property.
 *
 * @param token - The client token to validate
 * @returns An array of error messages if validation fails, or an empty array if valid
 *
 * Validation rules:
 * - Must be a string
 * - Must be between 1 and 64 characters long
 * - Must contain only printable ASCII characters
 */
export declare function validateClientToken(token: unknown): string[];
/**
 * Validates the description property.
 *
 * @param description - The description to validate
 * @returns An array of error messages if validation fails, or an empty array if valid
 *
 * Validation rules:
 * - Must be a string
 * - Maximum length of 2048 characters
 */
export declare function validateDescription(description: unknown): string[];
/**
 * Validates the grafanaVersion property.
 *
 * @param version - The Grafana version to validate
 * @returns An array of error messages if validation fails, or an empty array if valid
 *
 * Validation rules:
 * - Must be a string
 * - Must be between 1 and 255 characters long
 */
export declare function validateGrafanaVersion(version: unknown): string[];
/**
 * Validates the name property.
 *
 * @param name - The workspace name to validate
 * @returns An array of error messages if validation fails, or an empty array if valid
 *
 * Validation rules:
 * - Must be a string
 * - Must be between 1 and 255 characters long
 * - Can only contain alphanumeric characters, hyphens, dots, underscores, and tildes
 */
export declare function validateName(name: unknown): string[];
/**
 * Validates the networkAccessControl property.
 *
 * @param nac - The network access control configuration to validate
 * @returns An array of error messages if validation fails, or an empty array if valid
 *
 * Validation rules:
 * - Must be an object
 * - prefixLists (if present) must be an array with at most 5 items
 * - vpcEndpoints (if present) must be an array with at most 5 items
 */
export declare function validateNetworkAccessControl(nac: unknown): string[];
/**
 * Validates the organizationRoleName property.
 *
 * @param roleName - The organization role name to validate
 * @returns An array of error messages if validation fails, or an empty array if valid
 *
 * Validation rules:
 * - Must be a string
 * - Must be between 1 and 2048 characters long
 */
export declare function validateOrganizationRoleName(roleName: unknown): string[];
/**
 * Validates the SAML assertion attributes.
 *
 * @param obj - The SAML assertion attributes to validate
 * @returns An array of error messages if validation fails, or an empty array if valid
 *
 * Validation rules:
 * - Must be an object
 * - Each attribute must be a string
 * - Each attribute must be between 1 and 256 characters long
 * - Valid attribute keys are: 'email', 'groups', 'login', 'name', 'org', 'role'
 */
export declare function validateSamlAssertionAttributes(obj: unknown): string[];
/**
 * Validates the SAML IdP metadata.
 *
 * @param obj - The SAML IdP metadata to validate
 * @returns An array of error messages if validation fails, or an empty array if valid
 *
 * Validation rules:
 * - Must be an object
 * - url (if present) must be a string between 1 and 2048 characters long
 * - xml (if present) must be a string
 */
export declare function validateSamlIdpMetadata(obj: unknown): string[];
/**
 * Validates the SAML configuration.
 *
 * @param config - The SAML configuration to validate
 * @returns An array of error messages if validation fails, or an empty array if valid
 *
 * Validation rules:
 * - Must be an object
 * - idpMetadata is required and must be valid
 * - assertionAtrributes (if present) must be valid
 * - allowedOrganizations (if present) must be an array of strings with 1-256 elements
 * - loginValidityDuration (if present) must be a positive number
 * - roleValues (if present) must be an object with valid admin and editor arrays
 */
export declare function validateSamlConfiguration(config: unknown): string[];
/**
 * Validates the vpcConfiguration property.
 *
 * @param config - The VPC configuration to validate
 * @returns An array of error messages if validation fails, or an empty array if valid
 *
 * Validation rules:
 * - Must be an object
 * - securityGroups is required and must be an array with 1-5 items
 * - subnets is required and must be an array with 2-6 items
 */
export declare function validateVpcConfiguration(config: unknown): string[];
